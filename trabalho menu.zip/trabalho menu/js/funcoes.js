var n1, n2, soma;

n1 = 10;

n2 = 20;

soma= n1 + n2;